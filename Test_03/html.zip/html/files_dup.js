var files_dup =
[
    [ "accelgyro.h", "accelgyro_8h_source.html", null ],
    [ "accelgyrochart.h", "accelgyrochart_8h_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ],
    [ "maze.h", "maze_8h_source.html", null ],
    [ "micromouse.h", "micromouse_8h_source.html", null ]
];