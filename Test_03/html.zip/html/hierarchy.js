var hierarchy =
[
    [ "AccelGyro", "classAccelGyro.html", null ],
    [ "AccelGyroChart", "classAccelGyroChart.html", null ],
    [ "Maze", "classMaze.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "classMainWindow.html", null ]
    ] ],
    [ "QThread", null, [
      [ "Micromouse", "classMicromouse.html", null ]
    ] ]
];