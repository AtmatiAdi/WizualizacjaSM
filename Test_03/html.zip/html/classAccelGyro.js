var classAccelGyro =
[
    [ "AccelGyro", "classAccelGyro.html#a2edbd91d32357c9a51bab462c0f37404", null ],
    [ "Adddata", "classAccelGyro.html#a54f8c9cbdebda957de177bdf3e4ee14e", null ],
    [ "Callibrate", "classAccelGyro.html#af035c6fd93fb718f90b46a2f792dec35", null ],
    [ "GetAcceleration", "classAccelGyro.html#a264c3744a607f99309ee2ed4db42d8c3", null ],
    [ "GetDistance", "classAccelGyro.html#a5de50026e70ff3179b8e88ad87092244", null ],
    [ "GetVelocity", "classAccelGyro.html#a1caa9bea2b0878a426c3eeedac504a61", null ],
    [ "ResetDistance", "classAccelGyro.html#ae7e545aca1486c8ae83dc5825581f35f", null ],
    [ "ResetVelocity", "classAccelGyro.html#ac2eaeddb96bd8fdadb374368d6187ef1", null ],
    [ "Acceleration", "classAccelGyro.html#a231a7cde7e422d4a3e0a166e57fadca4", null ],
    [ "AccelScale", "classAccelGyro.html#aa029446caaff9263f40512ebaccec298", null ],
    [ "CAll", "classAccelGyro.html#a3b699fdfdf1bf6d66005d3fb4ee63a0f", null ],
    [ "Callibration", "classAccelGyro.html#a3ef0f2c80c4ec00ae1620b5e9bc4bbe9", null ],
    [ "CCount", "classAccelGyro.html#a738d7b50b0366243463831deb6afa434", null ],
    [ "Distance", "classAccelGyro.html#ad8abc07ada23ca8b748f7b5b7acb7b8e", null ],
    [ "DistParam", "classAccelGyro.html#a28f8f1891ede63533dcaa05cd290d437", null ],
    [ "GyroScale", "classAccelGyro.html#ab544f3143d78cb455005dd07fb90c252", null ],
    [ "RawData", "classAccelGyro.html#ab66466fdc48019ff53a55841f151775e", null ],
    [ "Timer", "classAccelGyro.html#a5f092f0b0f476bde8ca5420707356122", null ],
    [ "TmpCall", "classAccelGyro.html#a0312cfe111dc411afc2b9fd5a687d85e", null ],
    [ "Velocity", "classAccelGyro.html#a4a07749f0c34b023681f7afe4f4e8221", null ],
    [ "VelParam", "classAccelGyro.html#a37cfa3f27bd24a3c6a47e77bae443159", null ]
];