var searchData=
[
  ['addtologs_126',['addToLogs',['../classMainWindow.html#a4d32584efa9a8d85570c911a76882c2e',1,'MainWindow']]],
  ['append_127',['Append',['../classAccelGyroChart.html#a65d91403c1b8729e9c1b15e20a2450bb',1,'AccelGyroChart']]]
];
