var searchData=
[
  ['path_227',['path',['../classMainWindow.html#a6a3fad0f15ecad43de05aa2a42ddee38',1,'MainWindow']]],
  ['pixsize_5fpx_228',['PixSize_px',['../classMaze.html#a2b4bb709eec3d00efa5d0939c9792e45',1,'Maze']]]
];
