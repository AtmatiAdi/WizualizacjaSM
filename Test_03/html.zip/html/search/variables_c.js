var searchData=
[
  ['timer_241',['timer',['../classMainWindow.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]]
];
