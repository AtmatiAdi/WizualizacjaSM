var searchData=
[
  ['degree_5fdeg_207',['Degree_deg',['../classMainWindow.html#a11d9aca6cceed65621054dedc22c38b6',1,'MainWindow']]],
  ['device_208',['device',['../classMainWindow.html#a644ee4e747773d6ea59cdf4bee4deb49',1,'MainWindow']]],
  ['distance_5fcm_209',['Distance_cm',['../classMainWindow.html#a1f5aaae3453a918742028d3acad6cf69',1,'MainWindow']]]
];
