var searchData=
[
  ['eventfilter_130',['eventFilter',['../classMainWindow.html#ade305265b2120df2489a5ebeb07ebbe1',1,'MainWindow']]]
];
